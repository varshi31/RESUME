
Thank you for downloading HTML-Kit Tools.



* How do I install or uninstall HTML-Kit Tools?

  Please run HKToolsTrialSetup.exe to start the setup wizard.

  It can be removed by going to the "Uninstall program" section
  in the Windows Control Panel, or by running the uninstaller
  listed on "Programs > HTML-Kit Tools" Start Menu folder.


* How do I run HTML-Kit Tools?

  Select "Programs > HTML-Kit Tools" from the Windows Start Menu,
  or double click the desktop icon.


* Where do I check for updates?

  Select "Help > Check for Updates" from the main menu in HTML-Kit
  Tools, or visit http://www.html-kit.com/tools/changelog/?for=HTMLKitToolsTrial


* How do I verify the setup file?

  HKToolsTrialSetup.exe is 18 MB (19464966 bytes) in size
  and has a checksum of 6bf8a8b27a3c9a80df823625bcf8bf77 (MD5).

  For details please see: https://support.htmlkit.com/?verify=HTMLKitToolsTrial 


* I have more questions...

  Please feel free to send your questions and feedback using
  the "Help" menu.

  You can also view support articles and forums at:

  https://support.htmlkit.com/forums/?for=HTMLKitToolsTrial



Hope you'll enjoy using HTML-Kit!

Sincerely,
HTML-Kit Support
http://www.htmlkit.com/contact/
